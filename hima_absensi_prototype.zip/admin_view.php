<?php
include 'config.php';

$sql = "SELECT a.*, u.nim, u.nama, k.nama as kegiatan FROM absensi a
        LEFT JOIN users u ON u.id=a.user_id
        LEFT JOIN kegiatan k ON k.id=a.kegiatan_id
        ORDER BY a.jam_absen DESC LIMIT 200";
$res = $conn->query($sql);
?>
<html><body>
<h2>Rekap Absensi (Terakhir)</h2>
<table border=1 cellpadding=6 cellspacing=0>
<tr><th>#</th><th>NIM</th><th>Nama</th><th>Kegiatan</th><th>Jam</th><th>Lat</th><th>Lon</th><th>Device</th></tr>
<?php $i=1; while($r=$res->fetch_assoc()){ echo "<tr><td>{$i}</td><td>{$r['nim']}</td><td>{$r['nama']}</td><td>{$r['kegiatan']}</td><td>{$r['jam_absen']}</td><td>{$r['lat']}</td><td>{$r['lon']}</td><td>{$r['device_info']}</td></tr>"; $i++; } ?>
</table>
</body></html>
