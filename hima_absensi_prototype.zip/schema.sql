CREATE DATABASE IF NOT EXISTS hima_absensi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hima_absensi;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nim VARCHAR(50) UNIQUE,
  nama VARCHAR(150),
  password VARCHAR(255),
  role ENUM('anggota','admin') DEFAULT 'anggota',
  divisi VARCHAR(100),
  foto VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE kegiatan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(200),
  tanggal DATE,
  waktu_mulai TIME,
  waktu_selesai TIME,
  latitude DOUBLE,
  longitude DOUBLE,
  radius_m INT DEFAULT 50,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE absensi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  kegiatan_id INT,
  jam_absen DATETIME DEFAULT CURRENT_TIMESTAMP,
  lat DOUBLE,
  lon DOUBLE,
  foto_selfie VARCHAR(255),
  status ENUM('hadir','izin','alpha') DEFAULT 'hadir',
  device_info VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE
);

CREATE TABLE izin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  kegiatan_id INT,
  alasan TEXT,
  bukti VARCHAR(255),
  status ENUM('pending','disetujui','ditolak') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- contoh user admin
INSERT INTO users (nim,nama,password,role) VALUES ('0001','Admin HIMA',PASSWORD('admin123'),'admin');
