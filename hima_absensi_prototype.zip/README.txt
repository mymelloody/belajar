SISTEM ABSENSI HIMA - PROTOTYPE

Langkah cepat:
1. Ekstrak folder ke direktori web server (misal htdocs di XAMPP).
2. Import file schema.sql ke MySQL (phpMyAdmin atau command line).
3. Sesuaikan config.php bila diperlukan.
4. Buka anggota_absen.html untuk menguji absen (pastikan server berjalan dan file absen_api.php accessible).
5. Buka admin_view.php untuk melihat rekap absensi.

Note:
- Ini prototype sederhana tanpa autentikasi. Jangan pasang di server publik tanpa penambahan keamanan.
- Untuk testing lokasi, bisa jalankan di device dengan GPS atau gunakan fitur geolocation di browser (Chrome desktop bisa mensimulasikan lokasi melalui DevTools).
