<?php
include 'config.php';
header('Content-Type: application/json');

function haversine($lat1,$lon1,$lat2,$lon2){
    $R = 6371000; // m
    $dLat = deg2rad($lat2-$lat1);
    $dLon = deg2rad($lon2-$lon1);
    $a = sin($dLat/2)*sin($dLat/2)+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLon/2)*sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}

// Expecting JSON POST or form-data: nim, kegiatan_id, lat, lon, device
$nim = $_POST['nim'] ?? null;
$kegiatan_id = intval($_POST['kegiatan_id'] ?? 0);
$lat = floatval($_POST['lat'] ?? 0);
$lon = floatval($_POST['lon'] ?? 0);
$device = $_POST['device'] ?? '';

if(!$nim || !$kegiatan_id){
    echo json_encode(['success'=>false,'msg'=>'nim atau kegiatan_id kosong']); exit;
}

// get user
$stmt = $conn->prepare('SELECT id,nama FROM users WHERE nim=?');
$stmt->bind_param('s',$nim);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows==0){ echo json_encode(['success'=>false,'msg'=>'User tidak ditemukan']); exit; }
$user = $res->fetch_assoc();
$user_id = $user['id'];

// get kegiatan
$stmt = $conn->prepare('SELECT latitude,longitude,radius_m,nama FROM kegiatan WHERE id=?');
$stmt->bind_param('i',$kegiatan_id);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows==0){ echo json_encode(['success'=>false,'msg'=>'Kegiatan tidak ditemukan']); exit; }
$keg = $res->fetch_assoc();

$dist = haversine($keg['latitude'],$keg['longitude'],$lat,$lon);
if($dist > $keg['radius_m']){
    echo json_encode(['success'=>false,'msg'=>'Diluar radius absensi ('.round($dist).' m)']); exit;
}

// insert absensi
$stmt = $conn->prepare('INSERT INTO absensi (user_id,kegiatan_id,lat,lon,device_info) VALUES (?,?,?,?,?)');
$stmt->bind_param('iiiss',$user_id,$kegiatan_id,$lat,$lon,$device);
$ok = $stmt->execute();
if($ok) echo json_encode(['success'=>true,'msg'=>'Absen berhasil']);
else echo json_encode(['success'=>false,'msg'=>'Gagal menyimpan']);
?>
